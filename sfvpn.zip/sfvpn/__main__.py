from sfvpn import *
from importlib import import_module
from sfvpn.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("sfvpn.modules." + module_name)
bot.run_until_disconnected()

