from xolpanel import *

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline("[ Trial VMESS ]","trial-vmess"),
Button.inline("[ Create VMESS ]","create-vmess")],
[Button.inline("[ Delete VMESS ]","delete-vmess"),
Button.inline("[ Check Login VMESS ]","login-vmess")],
[Button.inline("[ Show All User VMESS ]","show-vmess")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ vmess Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» Service:** `vmess`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» 🤖@abecasdee**
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied🤣",alert=True)
		