from xolpanel import *

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" TRIAL TROJAN ","trial-trojan"),
Button.inline(" CREATE TROJAN ","create-trojan")],
[Button.inline(" CHECK TROJAN ","cek-trojan"),
Button.inline(" DELETE TROJAN ","delete-trojan")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**⚡ TROJAN MANAGER ⚡**
━━━━━━━━━━━━━━━━━━━━━━━ 
✅ **» Service:** `TROJAN`
✅ **» Hostname/IP:** `{DOMAIN}`
✅ **» ISP:** `{z["isp"]}`
✅ **» Country:** `{z["country"]}`
🤖 **» @abecasdee**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
